@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion
title YouTube without OBS Live - By Rasel

REM ================================================================
REM   YouTube without OBS Live  v1.0
REM   Author   : Rasel
REM   Gmail    : antorbrowser@gmail.com
REM   WhatsApp : +8801744595326
REM ================================================================

REM ==================== PATHS ====================
set "ROOT=%~dp0"
set "FFMPEG=%ROOT%FFmpeg\ffmpeg.exe"
set "FFPROBE=%ROOT%FFmpeg\ffprobe.exe"
set "VID_DIR=%ROOT%input_video"
set "IMG_DIR=%ROOT%input_image"
set "AUD_DIR=%ROOT%input_audio"

REM ==================== UNIQUE TEMP DIR ====================
:MAKE_TEMP
set "UID=%RANDOM%%RANDOM%"
set "TMPDIR=%TEMP%\YTLive_%UID%"
if exist "!TMPDIR!" goto MAKE_TEMP
mkdir "!TMPDIR!" 2>nul

REM ==================== CREATE FOLDERS ====================
if not exist "%VID_DIR%" mkdir "%VID_DIR%"
if not exist "%IMG_DIR%" mkdir "%IMG_DIR%"
if not exist "%AUD_DIR%" mkdir "%AUD_DIR%"

REM ==================== CHANNEL NAME ====================
cls
echo.
echo  ======================================================
echo        YouTube without OBS Live  v1.0
echo        By Rasel  ^|  antorbrowser@gmail.com
echo        WhatsApp : +8801744595326
echo  ======================================================
echo.
set "CHANNEL="
set /p "CHANNEL=  Enter Your Channel Name: "
if "!CHANNEL!"=="" set "CHANNEL=My Channel"

set /a INST=%RANDOM% %% 90 + 10
title [#!INST!] !CHANNEL! - YouTube without OBS Live

REM ==================== MAIN MENU ====================
:MENU
cls
echo.
echo  ======================================================
echo       YouTube without OBS Live  v1.0
echo  ======================================================
echo.
echo   [1]  Setup FFmpeg           (First Time Only)
echo   [2]  Long Video Live        (16:9  Horizontal)
echo   [3]  Short Video Live       (9:16  Vertical)
echo   [4]  Static Image + Audio   (24/7  No Video)
echo   [5]  About / Contact
echo   [6]  Exit
echo.
echo  ======================================================
echo   Channel : !CHANNEL!    Instance : #!INST!
echo  ======================================================
echo.
set "CH="
set /p "CH=  Select [1-6]: "

if "!CH!"=="1" goto SETUP
if "!CH!"=="2" goto LONG_LIVE
if "!CH!"=="3" goto SHORT_LIVE
if "!CH!"=="4" goto IMG_LIVE
if "!CH!"=="5" goto ABOUT
if "!CH!"=="6" goto DO_EXIT
echo   [!] Invalid choice. Try again.
timeout /t 1 >nul
goto MENU

REM ================================================================
REM  1. SETUP FFMPEG
REM ================================================================
:SETUP
cls
echo.
echo  ===== Setup FFmpeg =====
echo.
if exist "!FFMPEG!" (
    echo  [OK] FFmpeg is already installed!
    echo.
    pause
    goto MENU
)
if not exist "%ROOT%FFmpeg" mkdir "%ROOT%FFmpeg"
set "ZIPFILE=ffmpeg_latest.zip"
echo  Downloading FFmpeg... please wait.
echo.

REM -- Method 1: curl (same as working file)
where curl >nul 2>&1
if not errorlevel 1 (
    curl -L -o "%ZIPFILE%" "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
    if exist "%ZIPFILE%" goto EXTRACT_FFMPEG
)

REM -- Method 2: bitsadmin (same as working file)
bitsadmin /transfer "FFmpegDL" /download /priority normal ^
"https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" "%ZIPFILE%"
if exist "%ZIPFILE%" goto EXTRACT_FFMPEG

REM -- Method 3: PowerShell (same as working file)
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip' -OutFile '%ZIPFILE%'}"
if not exist "%ZIPFILE%" (
    echo  [ERROR] Download failed. Check your internet connection.
    echo.
    pause
    goto MENU
)

:EXTRACT_FFMPEG
echo  Extracting...
powershell -Command "Expand-Archive '%ZIPFILE%' 'ffmpeg_temp' -Force"
for /r "ffmpeg_temp" %%F in (ffmpeg.exe ffprobe.exe ffplay.exe) do (
    copy /y "%%F" "%ROOT%FFmpeg\" >nul 2>&1
)
rd /s /q "ffmpeg_temp" 2>nul
del /q "%ZIPFILE%" 2>nul
if exist "!FFMPEG!" (
    echo  [OK] FFmpeg installed successfully!
) else (
    echo  [ERROR] Something went wrong. Try again.
)
echo.
pause
goto MENU

REM ================================================================
REM  2. LONG VIDEO LIVE  (16:9)
REM ================================================================
:LONG_LIVE
if not exist "!FFMPEG!" (
    echo.
    echo  [!] FFmpeg not found. Please run Option 1 first.
    echo.
    pause
    goto MENU
)
cls
echo.
echo  ===== Long Video Live  (16:9 Horizontal) =====
echo.
set i=0
for %%F in ("%VID_DIR%\*.mp4" "%VID_DIR%\*.mov" "%VID_DIR%\*.mkv" "%VID_DIR%\*.webm" "%VID_DIR%\*.avi") do (
    set /a i+=1
    set "VID!i!=%%~fF"
    echo   !i!.  %%~nxF
)
if !i!==0 (
    echo  [!] No videos found in input_video folder.
    echo      Place a video file there and try again.
    echo.
    pause
    goto MENU
)
echo.
set "VC="
set /p "VC=  Select Video [1-!i!]: "
set "VIDFILE=!VID%VC%!"
if not defined VIDFILE (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
echo.
set "SKEY="
set /p "SKEY=  Enter YouTube Stream Key: "
if "!SKEY!"=="" (
    echo  [!] Stream key cannot be empty.
    pause
    goto MENU
)
echo.
echo  ===== Select Resolution =====
echo   [1]  720p   (1280x720 )  -- Best for low-end PC / 10+ streams
echo   [2]  1080p  (1920x1080)
echo   [3]  2K     (2560x1440)
echo   [4]  4K     (3840x2160)
echo.
set "RC="
set /p "RC=  Select [1-4]: "
if "!RC!"=="1" ( set "W=1280"&set "H=720" &set "VBIT=1500k"&set "MAXR=1500k"&set "BUF=3000k" &set "RNAME=720p"   )
if "!RC!"=="2" ( set "W=1920"&set "H=1080"&set "VBIT=2500k"&set "MAXR=2500k"&set "BUF=5000k" &set "RNAME=1080p"  )
if "!RC!"=="3" ( set "W=2560"&set "H=1440"&set "VBIT=4000k"&set "MAXR=4000k"&set "BUF=8000k" &set "RNAME=2K"     )
if "!RC!"=="4" ( set "W=3840"&set "H=2160"&set "VBIT=8000k"&set "MAXR=8000k"&set "BUF=16000k"&set "RNAME=4K"     )
if "!RNAME!"=="" (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
set "MIXFILE=!TMPDIR!\mix_16x9.mp4"
set "SCALE=scale=!W!:!H!:force_original_aspect_ratio=decrease,pad=!W!:!H!:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
REM -- check audio
set "ACHECK="
"!FFPROBE!" -v error -select_streams a -show_entries stream=index -of csv=p=0 "!VIDFILE!" > "!TMPDIR!\aud.txt" 2>nul
set /p ACHECK= < "!TMPDIR!\aud.txt"
del /q "!TMPDIR!\aud.txt" 2>nul
echo.
echo  Preparing video for !RNAME!... please wait.
echo.
if defined ACHECK (
    "!FFMPEG!" -y -hide_banner -loglevel error -stats ^
      -i "!VIDFILE!" ^
      -vf "!SCALE!" ^
      -c:v libx264 -preset ultrafast -crf 20 -g 60 -keyint_min 60 -sc_threshold 0 ^
      -c:a aac -b:a 128k -ar 44100 -ac 2 ^
      -movflags +faststart "!MIXFILE!"
) else (
    "!FFMPEG!" -y -hide_banner -loglevel error -stats ^
      -i "!VIDFILE!" ^
      -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 ^
      -vf "!SCALE!" ^
      -c:v libx264 -preset ultrafast -crf 20 -g 60 -keyint_min 60 -sc_threshold 0 ^
      -c:a aac -b:a 128k -ar 44100 -ac 2 ^
      -movflags +faststart -shortest "!MIXFILE!"
)
if not exist "!MIXFILE!" (
    echo.
    echo  [!] Preparation failed. Check your video file.
    pause
    goto MENU
)
title [#!INST!] !CHANNEL! - LIVE 16:9 !RNAME! - YouTube without OBS Live
echo.
echo  ============================================
echo   LIVE Stream Started!
echo   Channel    : !CHANNEL!
echo   Resolution : !RNAME! (!W!x!H!)
echo   Mode       : 24/7 Auto Loop
echo   Press Ctrl+C to stop.
echo  ============================================
echo.
"!FFMPEG!" -re -hide_banner -loglevel error -stats ^
  -stream_loop -1 -i "!MIXFILE!" ^
  -c:v copy -c:a copy ^
  -f flv "rtmp://a.rtmp.youtube.com/live2/!SKEY!"
del /q "!MIXFILE!" 2>nul
title [#!INST!] !CHANNEL! - YouTube without OBS Live
echo.
echo  Stream ended.
pause
goto MENU

REM ================================================================
REM  3. SHORT VIDEO LIVE  (9:16)
REM ================================================================
:SHORT_LIVE
if not exist "!FFMPEG!" (
    echo.
    echo  [!] FFmpeg not found. Please run Option 1 first.
    echo.
    pause
    goto MENU
)
cls
echo.
echo  ===== Short Video Live  (9:16 Vertical) =====
echo.
set i=0
for %%F in ("%VID_DIR%\*.mp4" "%VID_DIR%\*.mov" "%VID_DIR%\*.mkv" "%VID_DIR%\*.webm" "%VID_DIR%\*.avi") do (
    set /a i+=1
    set "VID!i!=%%~fF"
    echo   !i!.  %%~nxF
)
if !i!==0 (
    echo  [!] No videos found in input_video folder.
    echo      Place a video file there and try again.
    echo.
    pause
    goto MENU
)
echo.
set "VC="
set /p "VC=  Select Video [1-!i!]: "
set "VIDFILE=!VID%VC%!"
if not defined VIDFILE (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
echo.
set "SKEY="
set /p "SKEY=  Enter YouTube Stream Key: "
if "!SKEY!"=="" (
    echo  [!] Stream key cannot be empty.
    pause
    goto MENU
)
echo.
echo  ===== Select Resolution (Vertical) =====
echo   [1]  720p  Vertical  ( 720x1280 )  -- Best for low-end PC
echo   [2]  1080p Vertical  (1080x1920)
echo.
set "RC="
set /p "RC=  Select [1-2]: "
if "!RC!"=="1" ( set "W=720" &set "H=1280"&set "VBIT=1500k"&set "MAXR=1500k"&set "BUF=3000k"&set "RNAME=720p_Vertical"  )
if "!RC!"=="2" ( set "W=1080"&set "H=1920"&set "VBIT=2500k"&set "MAXR=2500k"&set "BUF=5000k"&set "RNAME=1080p_Vertical" )
if "!RNAME!"=="" (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
set "MIXFILE=!TMPDIR!\mix_9x16.mp4"
set "SCALE=scale=!W!:!H!:force_original_aspect_ratio=decrease,pad=!W!:!H!:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
set "ACHECK="
"!FFPROBE!" -v error -select_streams a -show_entries stream=index -of csv=p=0 "!VIDFILE!" > "!TMPDIR!\aud.txt" 2>nul
set /p ACHECK= < "!TMPDIR!\aud.txt"
del /q "!TMPDIR!\aud.txt" 2>nul
echo.
echo  Preparing video for 9:16 !RNAME!... please wait.
echo.
if defined ACHECK (
    "!FFMPEG!" -y -hide_banner -loglevel error -stats ^
      -i "!VIDFILE!" ^
      -vf "!SCALE!" ^
      -c:v libx264 -preset ultrafast -crf 20 -g 60 -keyint_min 60 -sc_threshold 0 ^
      -c:a aac -b:a 128k -ar 44100 -ac 2 ^
      -movflags +faststart "!MIXFILE!"
) else (
    "!FFMPEG!" -y -hide_banner -loglevel error -stats ^
      -i "!VIDFILE!" ^
      -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 ^
      -vf "!SCALE!" ^
      -c:v libx264 -preset ultrafast -crf 20 -g 60 -keyint_min 60 -sc_threshold 0 ^
      -c:a aac -b:a 128k -ar 44100 -ac 2 ^
      -movflags +faststart -shortest "!MIXFILE!"
)
if not exist "!MIXFILE!" (
    echo.
    echo  [!] Preparation failed. Check your video file.
    pause
    goto MENU
)
title [#!INST!] !CHANNEL! - LIVE 9:16 !RNAME! - YouTube without OBS Live
echo.
echo  ============================================
echo   LIVE Stream Started!
echo   Channel    : !CHANNEL!
echo   Resolution : !RNAME! (!W!x!H!)
echo   Mode       : 24/7 Auto Loop
echo   Press Ctrl+C to stop.
echo  ============================================
echo.
"!FFMPEG!" -re -hide_banner -loglevel error -stats ^
  -stream_loop -1 -i "!MIXFILE!" ^
  -c:v copy -c:a copy ^
  -f flv "rtmp://a.rtmp.youtube.com/live2/!SKEY!"
del /q "!MIXFILE!" 2>nul
title [#!INST!] !CHANNEL! - YouTube without OBS Live
echo.
echo  Stream ended.
pause
goto MENU

REM ================================================================
REM  4. STATIC IMAGE + AUDIO
REM ================================================================
:IMG_LIVE
if not exist "!FFMPEG!" (
    echo.
    echo  [!] FFmpeg not found. Please run Option 1 first.
    echo.
    pause
    goto MENU
)
cls
echo.
echo  ===== Static Image + Audio Live =====
echo.
set j=0
echo  -- Images (input_image folder) --
echo.
for %%F in ("%IMG_DIR%\*.jpg" "%IMG_DIR%\*.jpeg" "%IMG_DIR%\*.png") do (
    set /a j+=1
    set "IMG!j!=%%~fF"
    echo   !j!.  %%~nxF
)
if !j!==0 (
    echo  [!] No images found in input_image folder.
    echo      Place a .jpg or .png file there first.
    echo.
    pause
    goto MENU
)
echo.
set "IC="
set /p "IC=  Select Image [1-!j!]: "
set "IMGFILE=!IMG%IC%!"
if not defined IMGFILE (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
echo.
set k=0
echo  -- Audio (input_audio folder) --
echo.
for %%F in ("%AUD_DIR%\*.mp3" "%AUD_DIR%\*.aac" "%AUD_DIR%\*.wav" "%AUD_DIR%\*.m4a") do (
    set /a k+=1
    set "AUD!k!=%%~fF"
    echo   !k!.  %%~nxF
)
if !k!==0 (
    echo  [!] No audio found in input_audio folder.
    echo      Place a .mp3 or .wav file there first.
    echo.
    pause
    goto MENU
)
echo.
set "AC="
set /p "AC=  Select Audio [1-!k!]: "
set "AUDFILE=!AUD%AC%!"
if not defined AUDFILE (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
echo.
set "SKEY="
set /p "SKEY=  Enter YouTube Stream Key: "
if "!SKEY!"=="" (
    echo  [!] Stream key cannot be empty.
    pause
    goto MENU
)
echo.
echo  ===== Select Resolution =====
echo   [1]  720p   (1280x720 )  -- Best for low-end PC
echo   [2]  1080p  (1920x1080)
echo.
set "RC="
set /p "RC=  Select [1-2]: "
if "!RC!"=="1" ( set "W=1280"&set "H=720" &set "VBIT=1000k"&set "MAXR=1000k"&set "BUF=2000k"&set "RNAME=720p"  )
if "!RC!"=="2" ( set "W=1920"&set "H=1080"&set "VBIT=1500k"&set "MAXR=1500k"&set "BUF=3000k"&set "RNAME=1080p" )
if "!RNAME!"=="" (
    echo  [!] Invalid selection.
    pause
    goto MENU
)
title [#!INST!] !CHANNEL! - LIVE Image !RNAME! - YouTube without OBS Live
echo.
echo  ============================================
echo   LIVE Stream Started!
echo   Channel    : !CHANNEL!
echo   Resolution : !RNAME! (!W!x!H!)
echo   Mode       : Static Image + Loop Audio
echo   Press Ctrl+C to stop.
echo  ============================================
echo.
"!FFMPEG!" -re -hide_banner -loglevel error -stats ^
  -loop 1 -i "!IMGFILE!" ^
  -stream_loop -1 -i "!AUDFILE!" ^
  -vf "scale=!W!:!H!:force_original_aspect_ratio=decrease,pad=!W!:!H!:(ow-iw)/2:(oh-ih)/2,format=yuv420p" ^
  -c:v libx264 -preset ultrafast -tune stillimage ^
  -b:v !VBIT! -maxrate !MAXR! -bufsize !BUF! ^
  -g 60 -keyint_min 60 -sc_threshold 0 ^
  -c:a aac -b:a 128k -ac 2 -ar 44100 ^
  -f flv "rtmp://a.rtmp.youtube.com/live2/!SKEY!"
title [#!INST!] !CHANNEL! - YouTube without OBS Live
echo.
echo  Stream ended.
pause
goto MENU

REM ================================================================
REM  5. ABOUT
REM ================================================================
:ABOUT
cls
echo.
echo  ======================================================
echo.
echo     YouTube without OBS Live   v1.0
echo.
echo     Stream any video to YouTube LIVE without OBS.
echo     Supports 16:9, 9:16 Vertical and Image+Audio.
echo     Ultra lightweight -- run 10+ streams at once.
echo.
echo  ------------------------------------------------------
echo.
echo     Author   :  Rasel
echo     Gmail    :  antorbrowser@gmail.com
echo     WhatsApp :  +8801744595326
echo.
echo  ======================================================
echo.
pause
goto MENU

REM ================================================================
REM  EXIT
REM ================================================================
:DO_EXIT
if exist "!TMPDIR!" rd /s /q "!TMPDIR!" 2>nul
exit
