# 🎬 YouTube without OBS Live  v1.0

Stream any local video to YouTube Live — **no OBS, no complex software.**  
Supports **16:9 Horizontal**, **9:16 Vertical (Shorts)**, and **Static Image + Audio** modes.  
Ultra lightweight — run **10+ streams simultaneously** on a normal PC.

![Platform](https://img.shields.io/badge/Platform-Windows%2010%2F11-blue)
![Made by](https://img.shields.io/badge/Made%20by-Rasel-red)
![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Features

- **One-click FFmpeg setup** — auto-downloads, no manual install needed
- **Long Video Live (16:9)** — horizontal format for normal YouTube Live, any length, 24/7 loop
- **Short Video Live (9:16)** — vertical format for YouTube Shorts Live, any length, 24/7 loop
- **Static Image + Audio** — stream a photo + music 24/7, no video file needed
- **Ultra lightweight** — pre-processes once, then streams with zero re-encoding (`-c:v copy`)
- **10+ simultaneous instances** — run many streams on one normal PC
- **Channel name + Instance ID** shown in every window title
- **Auto audio detection** — works with or without audio track in your video
- **Auto silent audio** — adds silent track if video has no audio (YouTube requires audio)

---

## 📦 Requirements

- **Windows 10 / 11** (64-bit)
- **YouTube channel** with Live Streaming enabled
- **YouTube Stream Key** (from YouTube Studio)
- **Internet connection**
- Everything else is auto-installed by the script

---

## 🚀 Quick Start

1. Download `YouTube_without_OBS_Live.bat` and place it in any folder
2. Double-click to run
3. Type your **Channel Name** and press Enter
4. Choose **Option 1** — install FFmpeg (first time only, takes ~1 min)
5. Place your files in the correct folders (auto-created):
   - `input_video\` → your video files
   - `input_image\` → your image files (for image mode)
   - `input_audio\` → your audio files (for image mode)
6. Choose your streaming mode and follow the prompts

---

## 📁 Folder Structure

```
📂 Your Folder
 ├── YouTube_without_OBS_Live.bat   ← Main script
 ├── 📂 FFmpeg\                     ← Auto-created after setup
 ├── 📂 input_video\                ← .mp4  .mov  .mkv  .webm  .avi
 ├── 📂 input_image\                ← .jpg  .jpeg  .png
 └── 📂 input_audio\                ← .mp3  .aac  .wav  .m4a
```

---

## 🎛️ Streaming Modes

### Mode 2 — Long Video Live (16:9)
- Horizontal format for normal YouTube Live
- Any video length — loops automatically 24/7
- Resolutions: **720p / 1080p / 2K / 4K**

### Mode 3 — Short Video Live (9:16)
- Vertical format for YouTube Shorts Live
- Any video length — loops automatically 24/7
- Resolutions: **720×1280 / 1080×1920**

### Mode 4 — Static Image + Audio
- No video needed — just a photo + music file
- Audio loops endlessly
- Perfect for lofi streams, music streams, radio-style 24/7

---

## ⚙️ How It Works (Technical)

The script uses a **2-step approach** for maximum performance:

**Step 1 — Pre-process (once):**
```
Video → libx264 ultrafast → Clean MP4 with correct resolution + pixel format
```

**Step 2 — Stream (ultra lightweight):**
```
Clean MP4 → -c:v copy → FLV → RTMP → YouTube (NO re-encoding, almost ZERO CPU)
```

`-c:v copy` means FFmpeg just reads the file and sends it — no encoding work.  
This is why **10+ instances** can run at the same time on a normal PC.

---

## 🎛️ Bitrate Table (Optimized for Low-End PC)

| Resolution | Video Bitrate | Max Bitrate | Buffer Size |
|---|---|---|---|
| 720p  (1280×720)  | 1500 kbps | 1500 kbps | 3000 kbps |
| 1080p (1920×1080) | 2500 kbps | 2500 kbps | 5000 kbps |
| 2K    (2560×1440) | 4000 kbps | 4000 kbps | 8000 kbps |
| 4K    (3840×2160) | 8000 kbps | 8000 kbps | 16000 kbps |
| Image 720p        | 1000 kbps | 1000 kbps | 2000 kbps |
| Image 1080p       | 1500 kbps | 1500 kbps | 3000 kbps |

> **Tip:** For 10+ simultaneous streams on a low-end PC, use **720p**.

---

## ❓ Troubleshooting

| Problem | Solution |
|---|---|
| FFmpeg not found | Run **Option 1** to install FFmpeg |
| No videos listed | Place video files in `input_video` folder |
| No images listed | Place image files in `input_image` folder |
| No audio listed | Place audio files in `input_audio` folder |
| RTMP / Connection error | Check your Stream Key; make sure YouTube Live is enabled on your channel |
| Stream lags or stutters | Choose **720p** resolution or check your internet upload speed |
| Preparation failed | Make sure your video file is not corrupted |

---

## 👨‍💻 Author

| | |
|---|---|
| **Name** | Rasel |
| **Gmail** | antorbrowser@gmail.com |
| **WhatsApp** | +8801744595326 |

---

## 📄 License

This project is open source and provided for personal use.  
Feel free to modify and improve. Credit to the original author is appreciated.

**🎥 Happy Streaming!**
